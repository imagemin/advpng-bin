#ifndef __BINTREE3Z__H
#define __BINTREE3Z__H

#undef BT_NAMESPACE
#define BT_NAMESPACE NBT3Z

#define HASH_ZIP

#include "BinTree.h"

#undef HASH_ZIP

#endif

