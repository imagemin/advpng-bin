#ifndef __COMPRESSION_ARIPRICE_H
#define __COMPRESSION_ARIPRICE_H

namespace NCompression {
namespace NArithmetic {

const UINT32 kNumBitPriceShiftBits = 6;
const UINT32 kBitPrice = 1 << kNumBitPriceShiftBits;

}}

#endif
